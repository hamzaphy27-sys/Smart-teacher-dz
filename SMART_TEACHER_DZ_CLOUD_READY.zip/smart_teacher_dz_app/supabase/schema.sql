-- Smart Teacher DZ — Cloud Sync Schema (Supabase / PostgreSQL)
-- Aligned with local SQLite (Drift) schema and Algerian Law 18-07 data minimization.

create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  school_name text,
  wilaya text,
  subject_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.academic_years (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  label text not null, -- e.g. '2025-2026'
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.classes (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  academic_year_id uuid not null references public.academic_years(id) on delete cascade,
  sheet_name text not null,          -- e.g. '2100001'
  display_name text not null,        -- e.g. 'أولى متوسط 1'
  class_code text,                   -- hidden row 6 col A
  term_code text,                    -- hidden row 6 col B
  subject_code text,                 -- hidden row 6 col C
  school_code text,                  -- hidden row 6 col D
  grade_columns_json jsonb not null, -- [{"code":"01","label":"معدل تقويم النشاطات /20","col":5}, ...]
  created_at timestamptz not null default now()
);

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id) on delete cascade,
  matricule text not null,           -- 16-digit official ID
  official_order int not null,
  last_name text not null,
  first_name text not null,
  birth_date text,
  aliases_json jsonb not null default '[]'::jsonb,
  unique(class_id, matricule)
);

create table if not exists public.grades (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  column_code text not null,         -- '01', '04', '09'
  status text not null,              -- 'value' | 'absent' | 'excused' | 'missing'
  numeric_value numeric(5,2),
  source text not null,              -- 'manual' | 'ocr_confirmed' | 'ocr_corrected' | 'excel_import'
  confidence real,
  confirmed_at timestamptz,
  updated_at timestamptz not null default now(),
  unique(class_id, student_id, column_code)
);

-- Note: Raw student sheet photos stay ON-DEVICE by default and are auto-purged after export
-- to respect minors' privacy under Law 18-07.

alter table public.profiles enable row level security;
alter table public.academic_years enable row level security;
alter table public.classes enable row level security;
alter table public.students enable row level security;
alter table public.grades enable row level security;

create policy "owner_profiles" on public.profiles for all using (auth.uid() = id);
create policy "owner_years" on public.academic_years for all using (auth.uid() = teacher_id);
create policy "owner_classes" on public.classes for all using (auth.uid() = teacher_id);
create policy "owner_students" on public.students for all using (
  exists (select 1 from public.classes c where c.id = class_id and c.teacher_id = auth.uid())
);
create policy "owner_grades" on public.grades for all using (
  exists (select 1 from public.classes c where c.id = class_id and c.teacher_id = auth.uid())
);
